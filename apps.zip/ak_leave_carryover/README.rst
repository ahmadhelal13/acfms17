Time Off Carry Over for Odoo

License: General Public License, Version 3 (LGPL v3).
Author and maintainer: Abdullah Khalil (abdulah.khaleel@gmail.com).
Issues and bugs can be reported over github issues - https://github.com/abdulah-khaleel/leave-carry-over

