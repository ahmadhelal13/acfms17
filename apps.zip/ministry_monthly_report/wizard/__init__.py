# -*- coding: utf-8 -*-

from . import ministry_report_wizard
