`1.0.1`
-------
- **Improvement:** Compatibility with python 3.9

`1.0.0`
-------

- **Init version**
